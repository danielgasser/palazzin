<?php
/**
 * Realized with PhpStorm.
 * File: /packages/toess_lab_auto_complete_search/blocks/toess_lab_auto_complete_search_block/edit.php
 * Author: toesslab.ch
 * Date: 19.10.17
 * Time: 00:08
 */
defined('C5_EXECUTE') or die('Access Denied.');
$this->inc('form_setup_html.php', ['c' => $c, 'searchObj' => $controller]);
