<?php
/**
 * Realized with PhpStorm.
 * File: /packages/toess_lab_auto_complete_search/blocks/toess_lab_auto_complete_search_block/add.php
 * Author: toesslab.ch
 * Date: 19.10.17
 * Time: 00:08
 */
defined('C5_EXECUTE') or die('Access Denied.');
$searchObj = $controller;

$this->inc('form_setup_html.php', ['c' => $c]);
